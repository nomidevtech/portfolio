
import { Suspense } from "react";
import AddPostServerComponent from "./APSC";

export default function AddPost() {
    return (
        <Suspense fallback={<p>Loading...</p>}>
            <AddPostServerComponent />
        </Suspense>
    );
}